number = 4
factorial = 1
count = 1

while count <= number:
    factorial *= count
    count += 1

print("El resultado es:", factorial)
