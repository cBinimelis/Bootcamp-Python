var_1 = 8 
var_2 = 10.5
var_3 ="ejercicio"

set_1 = {var_1, var_2, var_3}

list_1 = list(set_1)
list_1.append(False)

print(list_1)