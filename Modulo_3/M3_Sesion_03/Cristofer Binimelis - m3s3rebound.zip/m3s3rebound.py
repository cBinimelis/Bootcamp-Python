# declaracion de variables
a=20
b=30

# operacion
resultado = a*b

# Imprimir
print(resultado)