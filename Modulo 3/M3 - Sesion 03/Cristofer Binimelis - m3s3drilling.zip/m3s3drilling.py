# Importar módulo
import math

# Declarar variable 
y = 81

# Calcular raíz
root = math.sqrt(y)

# Imprimir resultado
print(root)