p1 = {"name": "Pedro", "last_name": "Jorquera", "phone_number": "+56999887766"}
p2 = {"name": "Claudia", "last_name": "Rocha", "phone_number": "+56955443322"}
p3 = {"name": "Evelyn", "last_name": "Duran", "phone_number": "+56911002233"}

people = [p1, p2, p3]
print(people)
