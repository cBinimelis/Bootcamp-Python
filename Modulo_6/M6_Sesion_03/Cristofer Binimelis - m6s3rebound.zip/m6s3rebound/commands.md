| Instrucción                 | Comando                         |
| --------------------------- | ------------------------------- |
| Verificación de Python3     | `python -V`                     |
| Verificación de PIP         | `pip -V`                        |
| Instalar virtualenvwrapper  | `pip install virtualenvwrapper` |
| Verificar virtualenvwrapper | `pip list`                      |
