class Animal:
    def __init__(self, nombre, raza, edad, peso):
        self.nombre = nombre
        self.raza = raza
        self.edad = edad
        self.peso = peso


caballo = Animal("Zeus", "Pura sangre", "5 Años", "450kg")
leon = Animal("Boulder", "Atlas", "10 Años", "130kg")
