from django import forms
from .models import Brand, Model, Equipment


class BrandForm(forms.ModelForm):
    class Meta:
        model = Brand
        fields = ['name']


class ModelForm(forms.ModelForm):
    class Meta:
        model = Model
        fields = ['name']


class EquipmentForm(forms.ModelForm):
    class Meta:
        model = Equipment
        fields = ['serial', 'brand', 'model']
        widgets = {
            'serial': forms.TextInput(attrs={'class': 'form-control'}),
            'brand': forms.Select(attrs={'class': 'form-select'}),
            'model': forms.Select(attrs={'class': 'form-select'}),
        }
